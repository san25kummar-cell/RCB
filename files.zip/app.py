import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import random

# ── PAGE CONFIG ──────────────────────────────────────────
st.set_page_config(
    page_title="RCB Reality Check",
    page_icon="🏏",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ── CUSTOM CSS ───────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700;900&family=Poppins:wght@300;400;600&display=swap');

/* Base */
html, body, [class*="css"] {
    font-family: 'Poppins', sans-serif;
    background-color: #0a0a0a !important;
    color: #f0f0f0;
}
.stApp { background-color: #0a0a0a; }
section[data-testid="stSidebar"] { background: #111; border-right: 1px solid #222; }

/* Hide default Streamlit elements */
#MainMenu, footer, header { visibility: hidden; }
.block-container { padding-top: 1rem !important; max-width: 1200px; }

/* Hero */
.hero-wrapper {
    background: radial-gradient(ellipse 80% 60% at 50% 30%, rgba(204,0,0,0.20) 0%, transparent 70%),
                radial-gradient(ellipse 60% 40% at 80% 70%, rgba(212,175,55,0.08) 0%, transparent 60%),
                #0a0a0a;
    border-radius: 24px;
    padding: 60px 40px;
    text-align: center;
    border: 1px solid rgba(255,255,255,0.06);
    margin-bottom: 2rem;
    position: relative;
    overflow: hidden;
}
.hero-wrapper::before {
    content: '';
    position: absolute; inset: 0;
    background: repeating-linear-gradient(0deg,transparent,transparent 39px,rgba(255,255,255,0.015) 40px),
                repeating-linear-gradient(90deg,transparent,transparent 39px,rgba(255,255,255,0.015) 40px);
    border-radius: 24px;
}
.hero-badge {
    display: inline-block;
    background: linear-gradient(135deg, #cc0000, #8b0000);
    color: #fff; font-size: 0.7rem; font-weight: 700;
    letter-spacing: 3px; text-transform: uppercase;
    padding: 6px 18px; border-radius: 20px; margin-bottom: 1.5rem;
    box-shadow: 0 0 24px rgba(204,0,0,0.4);
}
.hero-title {
    font-family: 'Montserrat', sans-serif;
    font-size: 4.5rem; font-weight: 900;
    line-height: 0.95; letter-spacing: -2px;
    margin-bottom: 0.5rem;
}
.hero-sub {
    font-size: 1.1rem; color: #888; font-weight: 300;
    letter-spacing: 1px; margin-bottom: 2.5rem;
}
.hero-stat-card {
    display: inline-block;
    background: linear-gradient(135deg, rgba(204,0,0,0.15), rgba(0,0,0,0.4));
    border: 1px solid rgba(204,0,0,0.4);
    border-radius: 20px; padding: 1.5rem 3rem;
    box-shadow: 0 0 60px rgba(204,0,0,0.15);
    margin: 0 auto;
}
.hero-stat-label { font-size: 0.68rem; letter-spacing: 4px; color: #888; text-transform: uppercase; }
.hero-stat-number {
    font-family: 'Montserrat', sans-serif;
    font-size: 6rem; font-weight: 900; line-height: 1;
    color: #ff1a1a;
    text-shadow: 0 0 40px rgba(204,0,0,0.5), 0 0 80px rgba(204,0,0,0.2);
}
.hero-stat-sub { font-size: 0.85rem; color: #d4af37; font-weight: 600; letter-spacing: 2px; }

/* Section headers */
.section-tag {
    font-size: 0.68rem; font-weight: 700; letter-spacing: 4px;
    color: #d4af37; text-transform: uppercase;
    display: block; margin-bottom: 0.3rem;
}
.section-title {
    font-family: 'Montserrat', sans-serif;
    font-weight: 900; font-size: 2.2rem; line-height: 1.1;
    margin-bottom: 0.5rem;
}
.section-title em { font-style: normal; color: #ff1a1a; }
.divider {
    width: 60px; height: 3px;
    background: linear-gradient(90deg, #cc0000, #d4af37);
    border-radius: 2px; margin: 0.75rem 0 2rem;
}

/* Record Cards */
.rec-card {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 16px; padding: 1.5rem;
    transition: all 0.3s ease;
    position: relative; overflow: hidden;
    height: 100%;
}
.rec-card:hover { border-color: #cc0000; }
.rec-icon { font-size: 2rem; margin-bottom: 0.5rem; }
.rec-type { font-size: 0.65rem; font-weight: 700; letter-spacing: 3px; color: #d4af37; text-transform: uppercase; }
.rec-title { font-family: 'Montserrat', sans-serif; font-weight: 700; font-size: 1.1rem; margin: 0.3rem 0; }
.rec-val {
    font-family: 'Montserrat', sans-serif; font-size: 2.5rem; font-weight: 900;
    color: #ff1a1a; line-height: 1;
    text-shadow: 0 0 20px rgba(204,0,0,0.4);
}
.rec-sub { color: #888; font-size: 0.78rem; margin-top: 0.4rem; }
.rec-year {
    position: absolute; top: 1rem; right: 1rem;
    background: rgba(204,0,0,0.15); border: 1px solid rgba(204,0,0,0.3);
    color: #ff1a1a; font-size: 0.68rem; font-weight: 700;
    padding: 2px 9px; border-radius: 20px;
}

/* Kohli stat items */
.ksi {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 12px; padding: 1rem 1.25rem;
    display: flex; align-items: center; gap: 1rem;
    margin-bottom: 0.75rem;
}
.ksi-icon { font-size: 1.6rem; }
.ksi-label { font-size: 0.75rem; color: #888; }
.ksi-val-bad { font-family: 'Montserrat', sans-serif; font-weight: 700; font-size: 1.3rem; color: #ff1a1a; }
.ksi-val-ok  { font-family: 'Montserrat', sans-serif; font-weight: 700; font-size: 1.3rem; color: #d4af37; }

/* Meme cards */
.meme-card {
    background: linear-gradient(135deg, #1a1a1a, #222);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 12px; padding: 1.5rem;
    text-align: center; aspect-ratio: 1;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center; gap: 0.5rem;
    cursor: pointer; transition: all 0.3s;
}
.meme-card:hover { border-color: #cc0000; box-shadow: 0 0 24px rgba(204,0,0,0.2); }
.meme-emoji { font-size: 2.5rem; }
.meme-text { font-size: 0.82rem; font-weight: 600; line-height: 1.4; }
.meme-tag { font-size: 0.65rem; color: #d4af37; font-weight: 700; letter-spacing: 2px; }

/* Timeline */
.tl-item {
    background: rgba(255,255,255,0.04);
    border: 1px solid rgba(255,255,255,0.08);
    border-left: 3px solid #cc0000;
    border-radius: 0 14px 14px 0;
    padding: 1.25rem 1.5rem;
    margin-bottom: 1.25rem;
    position: relative;
}
.tl-item:hover { border-color: #d4af37; border-left-color: #d4af37; }
.tl-year { font-size: 0.68rem; font-weight: 700; letter-spacing: 3px; color: #d4af37; }
.tl-title { font-family: 'Montserrat', sans-serif; font-weight: 700; font-size: 1.05rem; margin: 0.3rem 0; }
.tl-desc { font-size: 0.82rem; color: #888; line-height: 1.5; }
.tl-score { font-family: 'Montserrat', sans-serif; font-size: 1.6rem; font-weight: 900; color: #ff1a1a; margin-top: 0.4rem; }

/* Fact box */
.fact-box {
    background: linear-gradient(135deg, rgba(204,0,0,0.1), rgba(212,175,55,0.05));
    border: 1px solid rgba(212,175,55,0.3);
    border-radius: 20px; padding: 2.5rem;
    text-align: center; min-height: 120px;
    display: flex; align-items: center; justify-content: center;
    box-shadow: 0 0 40px rgba(212,175,55,0.05);
}
.fact-text {
    font-family: 'Montserrat', sans-serif;
    font-size: 1.2rem; font-weight: 700; line-height: 1.6;
}

/* Footer */
.footer-box {
    background: #111; border-top: 1px solid rgba(255,255,255,0.08);
    border-radius: 16px; padding: 2rem;
    text-align: center; margin-top: 3rem;
}
.footer-logo {
    font-family: 'Montserrat', sans-serif; font-weight: 900; font-size: 1.4rem;
    background: linear-gradient(135deg, #ff1a1a, #d4af37);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}
.disclaimer {
    background: rgba(204,0,0,0.08); border: 1px solid rgba(204,0,0,0.2);
    border-radius: 12px; padding: 1rem 1.5rem;
    color: #888; font-size: 0.8rem; line-height: 1.6;
    max-width: 600px; margin: 1rem auto 0;
}

/* Streamlit button overrides */
.stButton > button {
    background: linear-gradient(135deg, #cc0000, #990000) !important;
    color: white !important; border: none !important;
    border-radius: 50px !important; font-weight: 700 !important;
    font-size: 0.9rem !important; padding: 0.6rem 2rem !important;
    box-shadow: 0 4px 24px rgba(204,0,0,0.4) !important;
    font-family: 'Poppins', sans-serif !important;
}
.stButton > button:hover {
    box-shadow: 0 8px 40px rgba(204,0,0,0.6) !important;
    transform: translateY(-2px) !important;
}
.stSelectbox > div > div {
    background: #1a1a1a !important; border-color: #333 !important;
    color: #f0f0f0 !important;
}
.stTabs [data-baseweb="tab-list"] { background: #111 !important; border-radius: 12px; gap: 4px; }
.stTabs [data-baseweb="tab"] { color: #888 !important; border-radius: 8px !important; font-weight: 600 !important; }
.stTabs [aria-selected="true"] { background: #cc0000 !important; color: white !important; }
</style>
""", unsafe_allow_html=True)

# ── DATA ─────────────────────────────────────────────────
records = [
    {"type": "batting", "icon": "💥", "category": "Lowest Total",         "title": "49 All Out",       "val": "49",    "sub": "vs Rajasthan Royals, 2009 · The iconic disaster",            "year": "2009"},
    {"type": "batting", "icon": "😰", "category": "Second Lowest",        "title": "70 All Out",       "val": "70",    "sub": "vs KKR, 2008 · The warm-up catastrophe",                    "year": "2008"},
    {"type": "losses",  "icon": "🏳️", "category": "Biggest Defeat",       "title": "Lost by 146 Runs", "val": "−146",  "sub": "vs CSK, 2015 · A masterclass in how not to bat",            "year": "2015"},
    {"type": "losses",  "icon": "🌊", "category": "Runs Chasing Fail",    "title": "Lost by 130+",     "val": "−130",  "sub": "vs MI, 2014 · When Mumbai showed no mercy",                 "year": "2014"},
    {"type": "streaks", "icon": "📉", "category": "Consecutive Losses",   "title": "6 on the Trot",    "val": "6",     "sub": "2019 Season · A streak that aged like fine wine… not",      "year": "2019"},
    {"type": "streaks", "icon": "😭", "category": "Playoff Exits",        "title": "15 Seasons",       "val": "15",    "sub": "IPL 2008–2022 without a title · Consistency in pain",       "year": "all"},
    {"type": "batting", "icon": "🏃", "category": "Lowest Chase Win",     "title": "Barely 82",        "val": "82",    "sub": "Just sneaked past an 81-run target · Sweating bullets",     "year": "2013"},
    {"type": "losses",  "icon": "🔥", "category": "Worst Bowling Day",    "title": "264 Conceded",     "val": "264",   "sub": "vs KKR, 2008 · The bowlers were on a scenic tour",          "year": "2008"},
    {"type": "streaks", "icon": "🎯", "category": "Dropped Catches",      "title": "7 in 1 Game",      "val": "7",     "sub": "vs MI, 2020 · Fielding Hall of Shame entry",                "year": "2020"},
    {"type": "batting", "icon": "🪦", "category": "Top Order Collapse",   "title": "3 for 0",          "val": "3/0",   "sub": "Three wickets without a run · Pure poetry",                 "year": "2022"},
    {"type": "losses",  "icon": "⚡", "category": "Super Over Drama",     "title": "Lost It Again",    "val": "0/1",   "sub": "Lost a Super Over they could have avoided",                 "year": "2019"},
    {"type": "streaks", "icon": "🕯️", "category": "Finals Appearances",   "title": "3 Finals",         "val": "3",     "sub": "2009, 2011, 2016 · 3 finals, 0 trophies 💔",               "year": "all"},
]

kohli_stats = [
    {"icon": "😶", "label": "Kohli vs CSK in finals",               "val": "8",    "unit": "runs",       "type": "bad"},
    {"icon": "📉", "label": "Strike rate when team needs 10+ rpo",  "val": "98.2", "unit": "SR",         "type": "bad"},
    {"icon": "💤", "label": "Ducks in IPL career",                  "val": "4",    "unit": "dismissals", "type": "bad"},
    {"icon": "🎯", "label": "Single-digit scores in knockouts",     "val": "6",    "unit": "times",      "type": "bad"},
    {"icon": "😤", "label": "Scores under 20 in playoffs",         "val": "12",   "unit": "innings",    "type": "bad"},
    {"icon": "👑", "label": "Orange Cap wins",                      "val": "2",    "unit": "seasons",    "type": "ok"},
    {"icon": "🔥", "label": "2016 Season Runs (legendary)",         "val": "973",  "unit": "runs",       "type": "ok"},
    {"icon": "🏏", "label": "Centuries vs RR (they still won)",     "val": "2",    "unit": "tons",       "type": "ok"},
]

memes = [
    {"emoji": "😭", "text": "RCB fans watching the final over needing 20 off 2 balls",           "tag": "FINALS ENERGY"},
    {"emoji": "🙏", "text": "Dear God, just one IPL trophy. I'll stop eating biryani for a month.", "tag": "FAN PRAYER"},
    {"emoji": "📉", "text": "RCB top order: gone in 4 overs. Virat: 'I'm carrying 10 men.'",     "tag": "BATTING ORDER"},
    {"emoji": "🔮", "text": "'Ee Sala Cup Namde' — RCB fans, every year since 2008",             "tag": "TRADITION"},
    {"emoji": "🤡", "text": "Me explaining to my friends why RCB will definitely win this year", "tag": "OPTIMISM UNLOCKED"},
    {"emoji": "😤", "text": "Kohli after scoring 70 while rest scored 40 combined",              "tag": "SOLO EFFORT"},
    {"emoji": "🏆", "text": "RCB trophy cabinet: *tumbleweed passes by*",                       "tag": "CABINET CHECK"},
    {"emoji": "🎭", "text": "RCB when they need 50 off 3: 'ah well, we tried'",                 "tag": "PHILOSOPHY"},
    {"emoji": "🔥", "text": "The RCB bowling attack seeing a flat pitch in Chinnaswamy",         "tag": "GROUND HORROR"},
    {"emoji": "💀", "text": "49 all out. FORTY. NINE. ALL. OUT.",                                "tag": "49 FOREVER"},
    {"emoji": "😂", "text": "RCB winning toss and choosing to bat: chaos speedrun any%",         "tag": "TOSS STRATEGY"},
    {"emoji": "🥲", "text": "Being an RCB fan: choosing pain as a lifestyle",                   "tag": "FAN LIFE"},
]

timeline_data = [
    {"year": "2009", "emoji": "💥", "title": "The 49 All Out",        "desc": "Bowled out for a historic 49 against Rajasthan Royals. IPL had found its villain.",              "score": "49"},
    {"year": "2009", "emoji": "🥈", "title": "Runners-Up (Again)",    "desc": "Lost the final to Deccan Chargers. First of three heartbreaking final appearances.",             "score": "RU"},
    {"year": "2011", "emoji": "💔", "title": "Final #2, Gone",        "desc": "CSK beat RCB in the final. Dhoni smiled. Millions of RCB fans did not.",                         "score": "RU"},
    {"year": "2013", "emoji": "😤", "title": "Kohli's War",           "desc": "Kohli scored 634 runs but RCB still exited early. One-man army vibes maxed out.",                "score": "634"},
    {"year": "2016", "emoji": "👑", "title": "Kohli's 973 Run Season","desc": "The greatest individual IPL season ever recorded. Team still lost in qualifiers.",               "score": "973"},
    {"year": "2016", "emoji": "😭", "title": "Final #3, Devastation", "desc": "Lost to SRH in the final. Third final, still no trophy. Fans invented new cuss words.",          "score": "RU"},
    {"year": "2019", "emoji": "📉", "title": "6-Game Losing Streak",  "desc": "Lost 6 consecutive matches. The streak was a monument to consistent inconsistency.",             "score": "0W6L"},
    {"year": "2022", "emoji": "🎉", "title": "Finally 4th!",          "desc": "Finished 4th in league stage! Oh wait, still no IPL trophy. But Virat cried and we cried.",      "score": "4th"},
    {"year": "2024", "emoji": "🏆", "title": "Virat Finally Lifts It!","desc": "RCB won their first IPL title! The 16-year wait ended. Bangalore erupted. Tears everywhere.",   "score": "🏆"},
]

fun_facts = [
    "RCB has played **3 finals** and won exactly **0 trophies** in those finals. That's a 0% conversion rate in the most important matches. 😭",
    "In 2009, RCB scored **49 all out** — that's less than the number of years the average cricket fan has been watching and hoping. 💀",
    "Virat Kohli scored **973 runs in 2016** — the best ever IPL season by any batsman. RCB still didn't win the title that year. 🎻",
    "RCB fans have said **'Ee Sala Cup Namde'** every year since 2008. It became a philosophy, not a prediction. 🔮",
    "The Chinnaswamy Stadium is a **batting paradise** — visiting teams score 220 and RCB scores 140. 🏟️",
    "RCB has had more **iconic collapses** than most teams have had total matches. Consistency is underrated. 📉",
    "In 2016, Kohli scored **4 centuries** in an IPL season. Most franchises score 4 centuries in their entire history. 👑",
    "A study (by us, just now) shows **93% of RCB fans** develop mild anxiety when Kohli gets out for under 30. 😤",
    "RCB's net run rate has been so negative at times, **economists referenced it** when explaining debt. 📊",
    "The official RCB anthem is 'Naanu RCBge' — which means 'I am for RCB.' Fans debate whether it's pride or a support group admission. 🎵",
]

# ── SESSION STATE ─────────────────────────────────────────
if "fact" not in st.session_state:
    st.session_state.fact = "Hit the button below to generate a fun stat! 🎲"
if "fact_idx" not in st.session_state:
    st.session_state.fact_idx = -1

# ── HERO ─────────────────────────────────────────────────
st.markdown("""
<div class="hero-wrapper">
  <div class="hero-badge">🏏 IPL SATIRE ZONE</div>
  <div class="hero-title">
    <span style="color:#ff1a1a">RCB</span> Reality
    <span style="color:#d4af37"> Check</span>
  </div>
  <div class="hero-sub">Stats, Chaos & Cricket Madness Since 2008</div>
  <div class="hero-stat-card">
    <div class="hero-stat-label">All-Time IPL Lowest Total</div>
    <div class="hero-stat-number">49</div>
    <div class="hero-stat-sub">ALL OUT · vs RR · 2009</div>
  </div>
</div>
""", unsafe_allow_html=True)

# ── TABS ──────────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "💀 Worst Records",
    "👑 Virat Kohli",
    "😂 Meme Gallery",
    "📅 Pain Timeline",
    "🎲 Fun Facts",
])

# ═══════════════════════════════════════════════
# TAB 1 — WORST RECORDS
# ═══════════════════════════════════════════════
with tab1:
    st.markdown("""
    <div class="section-tag">💀 Hall of Shame</div>
    <div class="section-title">Worst <em>Records</em></div>
    <div class="divider"></div>
    """, unsafe_allow_html=True)

    col_f1, col_f2, col_f3 = st.columns([2, 2, 3])
    with col_f1:
        filter_type = st.selectbox("Filter by Type", ["All", "batting", "losses", "streaks"], key="ftype")
    with col_f2:
        filter_year = st.selectbox("Filter by Year", ["All", "2008", "2009", "2013", "2014", "2015", "2019", "2020", "2022"], key="fyear")

    filtered = records
    if filter_type != "All":
        filtered = [r for r in filtered if r["type"] == filter_type]
    if filter_year != "All":
        filtered = [r for r in filtered if r["year"] == filter_year or r["year"] == "all"]

    cols = st.columns(3)
    for i, r in enumerate(filtered):
        with cols[i % 3]:
            st.markdown(f"""
            <div class="rec-card">
              <span class="rec-year">{r['year']}</span>
              <div class="rec-icon">{r['icon']}</div>
              <div class="rec-type">{r['type']}</div>
              <div class="rec-title">{r['title']}</div>
              <div class="rec-val">{r['val']}</div>
              <div class="rec-sub">{r['sub']}</div>
            </div>
            """, unsafe_allow_html=True)
        if (i + 1) % 3 == 0 and i + 1 < len(filtered):
            st.markdown("<br>", unsafe_allow_html=True)
            cols = st.columns(3)

# ═══════════════════════════════════════════════
# TAB 2 — KOHLI
# ═══════════════════════════════════════════════
with tab2:
    st.markdown("""
    <div class="section-tag">👑 King Kohli</div>
    <div class="section-title">Virat's <em>Interesting</em> Moments</div>
    <div class="divider"></div>
    """, unsafe_allow_html=True)

    col_k1, col_k2 = st.columns([1, 1])

    with col_k1:
        st.markdown("#### 📊 Selected Stats")
        for k in kohli_stats:
            css_class = "ksi-val-bad" if k["type"] == "bad" else "ksi-val-ok"
            st.markdown(f"""
            <div class="ksi">
              <span class="ksi-icon">{k['icon']}</span>
              <div>
                <div class="ksi-label">{k['label']}</div>
                <div class="{css_class}">{k['val']} <small style="font-size:0.65em;opacity:0.7">{k['unit']}</small></div>
              </div>
            </div>
            """, unsafe_allow_html=True)

    with col_k2:
        # Chart 1: Team Total vs Kohli
        matches    = ["v CSK 2015", "v MI 2019", "v KKR 2021", "v SRH 2022", "v GT 2022", "v LSG 2023"]
        team_total = [108, 92, 115, 68, 101, 126]
        kohli_runs = [8, 24, 5, 11, 30, 21]

        fig1 = go.Figure()
        fig1.add_bar(name="Team Total",  x=matches, y=team_total, marker_color="#cc0000",
                     marker_line_color="#ff1a1a", marker_line_width=1)
        fig1.add_bar(name="Kohli Runs",  x=matches, y=kohli_runs, marker_color="#d4af37",
                     marker_line_color="#f5d060", marker_line_width=1)
        fig1.update_layout(
            title="📉 Team Score vs Kohli Contribution",
            barmode="group",
            plot_bgcolor="#111", paper_bgcolor="#111",
            font=dict(color="#888", family="Poppins"),
            legend=dict(bgcolor="#1a1a1a", bordercolor="#333"),
            margin=dict(l=10, r=10, t=40, b=10),
        )
        fig1.update_xaxes(gridcolor="#222", tickfont=dict(size=10))
        fig1.update_yaxes(gridcolor="#222")
        st.plotly_chart(fig1, use_container_width=True)

        # Chart 2: Strike Rate
        seasons = ["2016","2017","2018","2019","2020","2021","2022","2023"]
        kohli_sr = [152, 121, 134, 128, 135, 118, 130, 141]
        team_sr  = [135, 118, 122, 110, 128, 115, 118, 129]

        fig2 = go.Figure()
        fig2.add_scatter(name="Kohli SR", x=seasons, y=kohli_sr,
                         line=dict(color="#d4af37", width=2.5), mode="lines+markers",
                         marker=dict(color="#d4af37", size=7), fill="tozeroy",
                         fillcolor="rgba(212,175,55,0.08)")
        fig2.add_scatter(name="Team SR", x=seasons, y=team_sr,
                         line=dict(color="#cc0000", width=2.5), mode="lines+markers",
                         marker=dict(color="#cc0000", size=7), fill="tozeroy",
                         fillcolor="rgba(204,0,0,0.06)")
        fig2.update_layout(
            title="⚡ Strike Rate Rollercoaster (2016–2023)",
            plot_bgcolor="#111", paper_bgcolor="#111",
            font=dict(color="#888", family="Poppins"),
            legend=dict(bgcolor="#1a1a1a", bordercolor="#333"),
            margin=dict(l=10, r=10, t=40, b=10),
        )
        fig2.update_xaxes(gridcolor="#222")
        fig2.update_yaxes(gridcolor="#222")
        st.plotly_chart(fig2, use_container_width=True)

# ═══════════════════════════════════════════════
# TAB 3 — MEMES
# ═══════════════════════════════════════════════
with tab3:
    st.markdown("""
    <div class="section-tag">😂 Dressing Room Leaks</div>
    <div class="section-title">Meme <em>Gallery</em></div>
    <div class="divider"></div>
    """, unsafe_allow_html=True)

    cols_m = st.columns(4)
    for i, m in enumerate(memes):
        with cols_m[i % 4]:
            st.markdown(f"""
            <div class="meme-card">
              <div class="meme-emoji">{m['emoji']}</div>
              <div class="meme-text">{m['text']}</div>
              <div class="meme-tag">{m['tag']}</div>
            </div>
            """, unsafe_allow_html=True)
        if (i + 1) % 4 == 0 and i + 1 < len(memes):
            st.markdown("<br>", unsafe_allow_html=True)
            cols_m = st.columns(4)

# ═══════════════════════════════════════════════
# TAB 4 — TIMELINE
# ═══════════════════════════════════════════════
with tab4:
    st.markdown("""
    <div class="section-tag">📅 Journey of Suffering</div>
    <div class="section-title">The <em>Pain</em> Timeline</div>
    <div class="divider"></div>
    """, unsafe_allow_html=True)

    col_t1, col_t2 = st.columns([1, 1])
    half = len(timeline_data) // 2 + len(timeline_data) % 2

    for i, t in enumerate(timeline_data):
        col = col_t1 if i < half else col_t2
        with col:
            st.markdown(f"""
            <div class="tl-item">
              <div class="tl-year">📅 {t['year']}</div>
              <div class="tl-title">{t['emoji']} {t['title']}</div>
              <div class="tl-desc">{t['desc']}</div>
              <div class="tl-score">{t['score']}</div>
            </div>
            """, unsafe_allow_html=True)

# ═══════════════════════════════════════════════
# TAB 5 — FUN FACTS
# ═══════════════════════════════════════════════
with tab5:
    st.markdown("""
    <div class="section-tag">🎲 Did You Know?</div>
    <div class="section-title">Funny <em>Stats</em> Generator</div>
    <div class="divider"></div>
    """, unsafe_allow_html=True)

    st.markdown(f"""
    <div class="fact-box">
      <div class="fact-text">{st.session_state.fact}</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    col_b1, col_b2, col_b3 = st.columns([2, 1, 2])
    with col_b2:
        if st.button("🎲 Generate Fact", use_container_width=True):
            idx = st.session_state.fact_idx
            choices = [i for i in range(len(fun_facts)) if i != idx]
            new_idx = random.choice(choices)
            st.session_state.fact_idx = new_idx
            st.session_state.fact = fun_facts[new_idx]
            st.rerun()

# ── FOOTER ───────────────────────────────────────────────
st.markdown("""
<div class="footer-box">
  <div class="footer-logo">RCB Reality Check 🏏</div>
  <br>
  <div class="disclaimer">
    ⚠️ <strong>Disclaimer:</strong> This website is for <em>entertainment and cricket analysis purposes only.</em>
    All stats are based on publicly available IPL data. We love RCB and Virat Kohli — this is pure affectionate satire.
    Please ee chai piyo aur match dekho. 🍵
  </div>
  <br>
  <div style="color:#555; font-size:0.75rem;">Made with ❤️ and 😭 by RCB fans · © 2024 · Ee Sala Cup Namde (Maybe)</div>
</div>
""", unsafe_allow_html=True)
